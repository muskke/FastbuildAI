import { BaseController } from "@common/base/controllers/base.controller";
import { PluginPermissions } from "@common/decorators/permissions.decorator";
import { PluginConsoleController } from "@common/decorators/plugin-controller.decorator";
import { Body, Delete, Get, Param, Patch, Post, Query } from "@nestjs/common";

import { ExampleDto } from "./dto/example.dto";
import { ExampleService } from "./example.service";

/**
 * 示例控制器
 */
@PluginConsoleController("example-template", "示例管理")
export class ExampleController extends BaseController {
    /**
     * 构造函数
     * @param exampleService 示例服务
     */
    constructor(private readonly exampleService: ExampleService) {
        super();
    }

    /**
     * 创建示例
     * @param createExampleDto 创建示例DTO
     * @returns 创建的示例
     */
    @Post()
    @PluginPermissions({
        code: "create",
        name: "创建示例",
        description: "示例插件创建接口",
    })
    async create(@Body() createExampleDto: ExampleDto) {
        return this.exampleService.createExample(createExampleDto);
    }

    /**
     * 获取示例列表
     * @returns 示例列表
     */
    @Get()
    async findAll() {
        return this.exampleService.findAll();
    }
}
