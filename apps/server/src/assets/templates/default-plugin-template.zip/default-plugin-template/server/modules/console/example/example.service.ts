import { BaseService } from "@common/base/services/base.service";
import { HttpExceptionFactory } from "@common/exceptions/http-exception.factory";
import { Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository } from "typeorm";

import { Example } from "../../../entities/example.entity";
import { ExampleDto } from "./dto/example.dto";

/**
 * 文章服务
 */
@Injectable()
export class ExampleService extends BaseService<Example> {
    /**
     * 构造函数
     * @param exampleRepository 文章仓库
     */
    constructor(
        @InjectRepository(Example)
        private readonly exampleRepository: Repository<Example>,
    ) {
        super(exampleRepository);
    }

    /**
     * 创建示例
     * @param exampleDto 创建示例DTO
     * @returns 创建的示例
     */
    async createExample(exampleDto: ExampleDto): Promise<string> {
        return "Hello World";
    }
}
