export class CreateExampleDto {}
