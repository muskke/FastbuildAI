export interface HelloWord {
    message: string;
}
