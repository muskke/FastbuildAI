var a=(r=>(r.DRAFT="draft",r.PUBLISHED="published",r))(a||{});export{a as A};
