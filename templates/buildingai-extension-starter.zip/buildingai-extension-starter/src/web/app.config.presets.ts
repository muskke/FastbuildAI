export { appConfigPresets } from "../../../../packages/web/buildingai-ui/app/app.config.presets";
