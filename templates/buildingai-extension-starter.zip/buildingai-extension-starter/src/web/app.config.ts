// import { defu } from "defu";

import { appConfigPresets } from "../../../../packages/web/buildingai-ui/app/app.config.presets";

export default defineAppConfig(appConfigPresets);
