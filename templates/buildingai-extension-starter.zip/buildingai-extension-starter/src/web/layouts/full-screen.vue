<template>
    <main class="flex h-full flex-1 flex-col overflow-x-hidden overflow-y-auto">
        <slot />
    </main>
</template>
