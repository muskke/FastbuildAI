import { defineBuildingAITsupConfig } from "@buildingai/extension-sdk";

export default defineBuildingAITsupConfig();
